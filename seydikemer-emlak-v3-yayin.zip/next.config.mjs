export default { reactStrictMode: true };
